package caesar.tree;

import caesar.Caesar;

public
class ASTTermX extends SimpleNode {
  private Operator operator;

  public ASTTermX(int id) {
    super(id);
  }

  public ASTTermX(Caesar p, int id) {
    super(p, id);
  }

  public void setOperator(Operator op) {
    this.operator = op;
  }

  public Operator getOperator() {
    return operator;
  }

  /** Accept the visitor. **/
  public Object jjtAccept(CaesarVisitor visitor, Object data) {
    return visitor.visit(this, data);
  }

  @Override
  public String toString() {
    return "TermX: " + operator;
  }  

}