package caesar.tree;
public enum Operator {
  PLUS, MINUS, MULTIPLY, DIVIDE, NULL,
  EQ, NE, LT, GT, LE, GE,
  ASSIGN
}